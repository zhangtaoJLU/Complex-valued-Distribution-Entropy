function  [cDistEn,R]=complexvalueddistributionentropy11(data,dim,MM,NN)
% % % % % % % % %%complex-valued distribution entropy-equal width criterion

N = length(data);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % % % % % % % % % % % % %%baseline remove
dataMat = zeros(dim,N-dim+1);
for i = 1:dim
    dataMat(i,:) = data(i:N-dim+i);
end
    tempMat=dataMat-mean(dataMat);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


R=[];
for i = 1:N-dim
    dist=[];
    % calculate Chebyshev distance, excluding self-matching case
    [dist,~]=max(tempMat(:,i+1:N-dim+1) - repmat(tempMat(:,i),1,N-dim+1-i));
    R=[R dist];
end

    phase=angle(R)+pi;
    range=abs(R);
    

MINA=min(range);MAXA=max(range);
bew=(MAXA-MINA)/MM;
edges=MINA+bew:bew:MAXA;
NUM=zeros(NN,MM);
    for ii=1:NN
        afs=[];
        if ii<NN
          afs=find((phase>=(2*pi/NN*(ii-1))) & (phase<(2*pi/NN*(ii))));
        elseif ii==NN
            afs=find((phase>=(2*pi/NN*(NN-1))) & (phase<=(2*pi)));
        end
          NUM(ii,:)=hist(range(afs),edges);
    end
    P1=reshape(NUM,1,NN*MM);
if any(P1)
    P1(P1==0)=[];%if elements of P1 are all 0
    p1=P1/sum(P1);
    cDistEn=(-(sum(p1.*(log2(p1)))))/log2(MM*NN);
    else
    cDistEn=0;
end