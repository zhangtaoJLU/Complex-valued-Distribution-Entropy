x=load('F090.txt');
%db10С������4��ֽ�
%һάС���ֽ�
[c,l]=wavedec(x,8,'db4');

%�ع���1-4��ϸ���ź�
d8=wrcoef('d',c,l,'db4',8);
d7=wrcoef('d',c,l,'db4',7);
d6=wrcoef('d',c,l,'db4',6);
d5=wrcoef('d',c,l,'db4',5);
d4=wrcoef('d',c,l,'db4',4);
d3=wrcoef('d',c,l,'db4',3);
d2=wrcoef('d',c,l,'db4',2);
d1=wrcoef('d',c,l,'db4',1);

%��ʾϸ���ź�
figure(2)
subplot(4,1,1);
plot(d4,'LineWidth',2);
ylabel('d4');
subplot(4,1,2);
plot(d3,'LineWidth',2);
ylabel('d3');
subplot(4,1,3);
plot(d2,'LineWidth',2);
ylabel('d2');
subplot(4,1,4);
plot(d2,'LineWidth',2);
ylabel('d1');
xlabel('ʱ��t/s');

%��Ϣ��
y=d1;
duan=100;
x_min=min(y);
x_max=max(y);
maxf(1)=abs(x_max-x_min);
maxf(2)=x_min;
duan_t=1.0/duan;
jiange=maxf(1)*duan_t;
% for i=1:10
% pnum(i)=length(find((y_p>=(i-1)*jiange)&(y_p<i*jiange)));
% end
pnum(1)=length(find(y<maxf(2)+jiange));
for i=2:duan-1
    pnum(i)=length(find((y>=maxf(2)+(i-1)*jiange)&(y<maxf(2)+i*jiange)));
end
pnum(duan)=length(find(y>=maxf(2)+(duan-1)*jiange));
%sum(pnum)
ppnum=pnum/sum(pnum);%ÿ�γ��ֵĸ���
%sum(ppnum)
Hx=0;
for i=1:duan
    if ppnum(i)==0
        Hi=0;
    else
        Hi=-ppnum(i)*log2(ppnum(i));
    end
    Hx=Hx+Hi;
end
Hx


%��һ��ϸ���źŵİ�����
y=hilbert(d1);
ydata=abs(y);
figure(4);
plot(ydata);
y=y-mean(y);
fs=173.6;
nfft=1024;
p=abs(fft(ydata,nfft));
figure(3);
plot((0:nfft/2-1)/nfft*fs,p(1:nfft/2));
xlabel('Ƶ��f/Hz');
ylabel('������P/W');

