function RESULT=caseCD_E(~,~,Y_3,Y_4,Y_5,no_K,fun)

train_X1=[Y_3;Y_4;Y_5];
% mapminmaxΪMATLAB�Դ��Ĺ�һ������
[dataset_scale,~] = mapminmax(train_X1',0,1);
mappedX = dataset_scale';

Y3=mappedX(1:100,:);Y4=mappedX(101:200,:);Y5=mappedX(201:300,:);

data(1)={[Y3;Y4]};data(2)={Y5};

cat=length(data);
for i=1:50
[accuracy,sen]=KfoldcrossvalidationRFCGTWOCLASS(data,cat,10,no_K,fun);
ACC(i,1)=mean(accuracy);
SEN(i,:)=mean(sen');
end
RESULT=[SEN(:,2) SEN(:,1) ACC SEN(:,3)];