function predict_label=RFCglobelclassificationTWOCLASS(train_wine11,test_wine11,train_wine_labels,test_wine_labels,no_K,fun)
% NNC1=size(train_wine11,2);
% THR=0.05;
% for mm=1:NNC1
%     xx=train_wine11(:,mm);group=[train_wine_labels];
% % % %     Fisher1(1,mm)=kruskalwallis(xx,group,'off');
% DDSADA1=find(train_wine_labels==1);DDSADA2=find(train_wine_labels==2);
% [~,Fisher1(1,mm)]=kstest2(train_wine_labels(DDSADA1),train_wine_labels(DDSADA2));
% end
% nn1=find(Fisher1 <THR);
% train_wine1=train_wine11(:,nn1);
% test_wine1=test_wine11(:,nn1);



% %%��������ѡ����
train_wine1=train_wine11;
test_wine1=test_wine11;


%%����Ԥ����
% ����Ԥ����,��ѵ�����Ͳ��Լ���һ����[0,1]����
[mtrain,~] = size(train_wine1);
[mtest,~] = size(test_wine1);

dataset = [train_wine1;test_wine1];
% mapminmaxΪMATLAB�Դ��Ĺ�һ������
[dataset_scale,~] = mapminmax(dataset',0,1);
dataset_scale = dataset_scale';

train_wine = dataset_scale(1:mtrain,:);
test_wine = dataset_scale( (mtrain+1):(mtrain+mtest),: );
%% ѡ����ѵ�SVM����c&g

% % %%GA LS-SVM
% % [bestacc,bestc,bestg] = psoSVMcgForClass(train_wine_labels,train_wine);
% [bestacc,bestc,bestg] = gaLSSVMcgForClass(train_wine_labels,train_wine);
% model = initlssvm(train_wine,train_wine_labels,'c',bestc,bestg,'RBF_kernel');% RBF_kernel lin_kernel  poly_kernel
% model = trainlssvm(model);
% % % ʹ�ò������ݶԽ�����LS-SVM����
% predict_label = simlssvm(model,test_wine);


% %%LS-SVM(2)
% model = initlssvm(train_wine,train_wine_labels,'c',[],[],'lin_kernel');% RBF_kernel lin_kernel  poly_kernel
% model = tunelssvm(model,'simplex','crossvalidatelssvm',{2,'misclass'},'code_OneVsOne');%'gridsearch/simplex'ѡ���Ż���ʽ
% model = trainlssvm(model);
% % % ʹ�ò������ݶԽ�����LS-SVM����
% predict_label = simlssvm(model,test_wine);

% % figure;
% % plotlssvm(model,[],250);

% %%RFC(3)
% Factor = TreeBagger(5*no_K, train_wine, train_wine_labels);
% [predict_label11,~] = predict(Factor,  test_wine);
% predict_label1=cell2mat(predict_label11);
% predict_label=str2num(predict_label1);



% % % %%GA-SVM(1)
% % [bestacc,bestc,bestg] = psoSVMcgForClass(train_wine_labels,train_wine);
% [~,bestc,bestg] = gaSVMcgForClass(train_wine_labels,train_wine);
% % [bestacc,bestc,bestg] = SVMcgForClass(train_wine_labels,train_wine);
% %% ������ѵĲ�������SVM����ѵ��
% cmd = ['-c ',num2str(bestc),' -g ',num2str(bestg)];
% model = svmtrain(train_wine_labels,train_wine,cmd);
% %% SVM����Ԥ��
% [predict_label,~,~] = svmpredict(test_wine_labels,test_wine,model);
% % % % svmplot(train_wine_labels,train_wine,model);


if fun==1

% %% KNN����(4)
Factor = ClassificationKNN.fit(train_wine, train_wine_labels, 'NumNeighbors',no_K);
predict_label =  predict(Factor, test_wine);
    

elseif fun==2    
% % ELM����/ѵ��
[IW,B,LW,TF,TYPE] = elmtrain(train_wine',train_wine_labels',5*no_K,'hardlim',1);%sig  sin  hardlim
%ELM�������
predict_label111= elmpredict(test_wine',IW,B,LW,TF,TYPE);
predict_label=predict_label111';


elseif fun==3
% % ELM����/ѵ��
[IW,B,LW,TF,TYPE] = elmtrain(train_wine',train_wine_labels',5*no_K,'sig',1);%sig  sin  hardlim
%ELM�������
predict_label111= elmpredict(test_wine',IW,B,LW,TF,TYPE);
predict_label=predict_label111';

elseif fun==4
% % ELM����/ѵ��
[IW,B,LW,TF,TYPE] = elmtrain(train_wine',train_wine_labels',5*no_K,'sin',1);%sig  sin  hardlim
%ELM�������
predict_label111= elmpredict(test_wine',IW,B,LW,TF,TYPE);
predict_label=predict_label111';    

elseif fun==5    
%%RFC(3)
Factor = TreeBagger(2*no_K, train_wine, train_wine_labels);
[predict_label11,~] = predict(Factor,  test_wine);
predict_label1=cell2mat(predict_label11);
predict_label=str2num(predict_label1);


elseif fun==6   
% % % % % % % % % % SVM
bestc=no_K/5;bestg=80;
model = initlssvm(train_wine,train_wine_labels,'c',bestc,bestg,'lin_kernel');% RBF_kernel lin_kernel  poly_kernel
model = trainlssvm(model);
% % ʹ�ò������ݶԽ�����LS-SVM����
predict_label = simlssvm(model,test_wine);



elseif fun==7  
% % % % % % % % % % SVM
bestc=no_K/5;bestg=80;
model = initlssvm(train_wine,train_wine_labels,'c',bestc,bestg,'RBF_kernel');% RBF_kernel lin_kernel  poly_kernel
model = trainlssvm(model);
% % ʹ�ò������ݶԽ�����LS-SVM����
predict_label = simlssvm(model,test_wine);
    
    
elseif fun==8
%% Fuzzy KNN classifier
[predict_label,~, ~] = fknn(train_wine, train_wine_labels, test_wine, ...
	    [], no_K, 0, true);%false   true

end
% % % % % % Here you design a radial basis network, given inputs P and targets T.
% % % % net = newgrnn(train_wine',train_wine_labels',no_K);
% % % % % % The network is simulated for a new input.
% % % % 
% % % % predict_label= sim(net,test_wine');
% % % % predict_label=(floor(predict_label))';