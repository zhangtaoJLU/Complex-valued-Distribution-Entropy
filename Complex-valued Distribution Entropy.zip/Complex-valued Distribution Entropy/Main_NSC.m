clear all;
close all;
warning off;
clc;

%%data_length
ghf=128*8;
%%parameters of Complex-valued Distribution Entropy
dim=10;
M=60;
nn=50;
%%The base of logarithmic energy
GFF=2.71828; 
% % %parameters of flexible analytic wavelet transform
p = 9;%%e
q = 10;%%f
r = 5;%%g
s = 6;%%h
bet = 0.7*r/s;
J = 16; % number of stages
gam = 7; % this is the chirp parameter
N = ceil(ghf);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%                                                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%              Feature extraction                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%                                                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%           Set E     ictal                                    %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
AE = dir(fullfile('NSC EEG dataset\ictal','*.mat'));
AE = struct2cell(AE);
numE = size(AE);
for k =1:numE(2)
    qE(k) = AE(1,k);% �ҳ�name����
end
for k = 1:numE(2)
    newpathE = strcat('NSC EEG dataset\ictal','\',qE(k));
    dataE{k} = load(char(newpathE));
end


for k=1:numE(2)
%%raw EEG of Set E
    bb=dataE{1,k}();
    cc=struct2cell(bb);
    x=cell2mat(cc);

%%Applying flexible analytic wavelet transform on truncated EEG
[F] = CreateFilters(N,p,q,r,s,bet,J); %without the chirp parameter
ewt= RAnDwt(x,p,q,r,s,J,F);
x1=[];x2=[];
for ii=1:J
%%Below calculate CVDistEn1 and LE of each wavelet subband,
%%if you want to calculate CVDistEn2, just replace function
%%"complexvalueddistributionentropy22"  by "complexvalueddistributionentropy22"
x1(1,ii) = complexvalueddistributionentropy22(ewt{ii,1}(),dim,M,nn);
x2(1,ii) = complexvalueddistributionentropy22(ewt{ii,2}(),dim,M,nn);
x3(1,ii) = log(sum(abs(ewt{ii,1}())))/log(GFF);x4(1,ii) = log(sum(abs(ewt{ii,2}())))/log(GFF);
end
% w=[];
featureE(k,:)=[x1 x2 x3 x4];
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%           Set D  interictal                                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
AD = dir(fullfile('NSC EEG dataset\interictal','*.mat'));
AD = struct2cell(AD);
numD = size(AD);
for k =1:numD(2)
    qD(k) = AD(1,k);% �ҳ�name����
end
for k = 1:numD(2)
    newpathD = strcat('NSC EEG dataset\interictal','\',qD(k));
    dataD{k} = load(char(newpathD));
end


for k=1:numD(2)
%%raw EEG of Set D   
    bb=dataD{1,k}();
    cc=struct2cell(bb);
    x=cell2mat(cc);

%%Applying flexible analytic wavelet transform on truncated EEG
[F] = CreateFilters(N,p,q,r,s,bet,J); %without the chirp parameter
ewt= RAnDwt(x,p,q,r,s,J,F);
x1=[];x2=[];
for ii=1:J
%%Below calculate CVDistEn1 and LE of each wavelet subband,
%%if you want to calculate CVDistEn2, just replace function
%%"complexvalueddistributionentropy22"  by "complexvalueddistributionentropy22"
x1(1,ii) = complexvalueddistributionentropy22(ewt{ii,1}(),dim,M,nn);
x2(1,ii) = complexvalueddistributionentropy22(ewt{ii,2}(),dim,M,nn);
x3(1,ii) = log(sum(abs(ewt{ii,1}())))/log(GFF);x4(1,ii) = log(sum(abs(ewt{ii,2}())))/log(GFF);
end
% w=[];
featureD(k,:)=[x1 x2 x3 x4];
end


featureA=zeros(size(featureD,1),size(featureD,2));
featureB=zeros(size(featureD,1),size(featureD,2));
featureC=zeros(size(featureD,1),size(featureD,2));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%                                                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%               Classification                                              %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%                                                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

DATA(1)={featureA};DATA(2)={featureB};DATA(3)={featureC};DATA(4)={featureD};DATA(5)={featureE};

%%clasifier=1,2,...,8 corresponding to KNN, HAR-ELM, SIG-ELM, SIN-ELM, RF,
%%LIN-SVM, RBF-SVM and FKNN, respectively
clasifier=8;
%%Influence of number of neighbors of FKNN
for no_K=1:40
CASE_CD_E_no_K1_M50=caseCD_E1(DATA{1}(),DATA{2}(),DATA{3}(),DATA{4}(),DATA{5}(),no_K,clasifier);
ALLRESULT_CASE_CD_E(no_K)={CASE_CD_E_no_K1_M50};
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%                                                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%               Plot results                                                %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%                                                                           %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

LW=1;MS=4;
MM1=length(ALLRESULT_CASE_CD_E);
for i=1:MM1
    x=ALLRESULT_CASE_CD_E{1,i}();
    KNNmean(i,:)=mean(x);
end


figure;
plot(KNNmean(:,1),'-*','MarkerSize',MS,'LineWidth',LW); % ���ƾֲ�����ͼ    
hold on;
plot(KNNmean(:,2),'-O','MarkerSize',MS,'LineWidth',LW); % ���ƾֲ�����ͼ
hold on;
plot(KNNmean(:,3),'-<','MarkerSize',MS,'LineWidth',LW); % ���ƾֲ�����ͼ
hold on;
plot(KNNmean(:,4),'-Xr','MarkerSize',MS,'LineWidth',LW); % ���ƾֲ�����ͼ
title('Performance of fKNN');
xlabel('Number of neighbors');xlim([0 50]);ylabel('Value(%)');
[aFKNN,bFKNN]=max(KNNmean(:,4));
legend('SPE','SEN','ACC','MCC');