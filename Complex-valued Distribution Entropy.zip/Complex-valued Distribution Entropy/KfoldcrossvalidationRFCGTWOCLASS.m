function [accuracy,SEN]=KfoldcrossvalidationRFCGTWOCLASS(data,K_class,K_fold,no_K,fun)
% macc,msen,mspe,mppv,sacc,ssen,sspe,sppv,
% This function performs K_fold  cross validation for K_class data
% data is a N*M*K_class 3D matrix where N is number of samples of each
% class and M is the demination of feature

% inputs:
% data: the whole feature data of all samples (cell style)
% K_class: number of classified classes
% K_fold��K_fold��cross validation
% PART:number of parts along time axis
% NNF:number of dimensionality of a local feature vector
% output:
% macc,msen,mspe,mppv are the mean values of ACC,SEN, SPE, PPV
% macc,msen,mspe,mppv are the standrad devition of ACC,SEN, SPE, PPV

for i=1:K_class
    [Ni, Mi]=size(data{i}());
    N(i)=Ni;M(i)=Mi;
    meanN(i)=floor(Ni/K_fold+0.01);
    rnN(i)={rand(1,Ni)};
end

for j=1:K_fold
    
    %%%�����е����ݽ���K_fold�ȷ�
    if j==1
    test_wine=[];train_wine=[];test_wine_labels =[];train_wine_labels =[];
        for k=1:K_class
            Rk1=rnN{k}();
            [~,rn]=sort(Rk1);      %�����ǽ�������m�Ǵ�С������������У�
            test_wine=[test_wine;data{k}(rn(1:meanN(k)),:)];
            test_wine_labels =[test_wine_labels;k*ones(meanN(k),1)];
            train_wine=[train_wine;data{k}(rn(meanN(k)+1:end),:)];
            train_wine_labels =[train_wine_labels;k*ones(N(k)-meanN(k),1)];
        end
    elseif j>1 && j<K_fold
    test_wine=[];train_wine=[];test_wine_labels =[];train_wine_labels =[];
        for k=1:K_class
            Rk1=rnN{k}();
            [~,rn]=sort(Rk1);      %�����ǽ�������m�Ǵ�С������������У�
            test_wine=[test_wine;data{k}(rn((j-1)*meanN(k)+1:j*meanN(k)),:)];
            test_wine_labels =[test_wine_labels;k*ones(meanN(k),1)];
            train_wine=[train_wine;data{k}(rn(j*meanN(k)+1:end),:)];
            train_wine=[train_wine;data{k}(rn(1:(j-1)*meanN(k)),:)];
            train_wine_labels =[train_wine_labels;k*ones(N(k)-meanN(k),1)];
        end
    else
    test_wine=[];train_wine=[];test_wine_labels =[];train_wine_labels =[];
    	 for k=1:K_class
            Rk1=rnN{k}();
            [~,rn]=sort(Rk1);      %�����ǽ�������m�Ǵ�С������������У�
            test_wine=[test_wine;data{k}(rn(N(k)-meanN(k)+1:N(k)),:)];
            test_wine_labels =[test_wine_labels;k*ones(meanN(k),1)];
            train_wine=[train_wine;data{k}(rn(1:N(k)-meanN(k)),:)];
            train_wine_labels =[train_wine_labels;k*ones(N(k)-meanN(k),1)];
        end
    end

    
    %%%ʹ�õȷֺ�����ݽ���ѵ���Ͳ��ԣ���
    %%%ע��train_wine/test_wine ÿһ�мȰ�����ȫ������������Ҳ�����˾ֲ����������������и�ʽΪ��
    %%%�ֲ���������1 �ֲ���������2 �ֲ���������3 �ֲ���������4 ȫ����������
    
%%global+local classification
    globeltrain_wine=train_wine;globeltest_wine=test_wine;
    globeltrain_wine_labels=train_wine_labels;
    globelpredict_label=RFCglobelclassificationTWOCLASS(globeltrain_wine,globeltest_wine,globeltrain_wine_labels,test_wine_labels,no_K,fun);
    
    if K_class==2
        seclass1=find(test_wine_labels==1);
        seclass2=find(test_wine_labels==2);
        TP=length(find(globelpredict_label(seclass2)==2));
        TN=length(find(globelpredict_label(seclass1)==1));
        FP=length(find(globelpredict_label(seclass1)==2));
        FN=length(find(globelpredict_label(seclass2)==1));
        sen=TP/(TP+FN)*100;
        spe=TN/(TN+FP)*100;
        mcc=(TP*TN-FP*FN)/((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))^0.5*100;
        
%         sen1=length(find(globelpredict_label(seclass1)==1))/length(seclass1)*100;
%         sen2=length(find(globelpredict_label(seclass2)==2))/length(seclass2)*100;
        SEN(:,j)=[sen;spe;mcc];
        clear seclass1;clear seclass2;
        
    elseif K_class==3
        seclass1=find(test_wine_labels==1);
        seclass2=find(test_wine_labels==2);
        seclass3=find(test_wine_labels==3);
        sen1=length(find(globelpredict_label(seclass1)==1))/length(seclass1)*100;
        sen2=length(find(globelpredict_label(seclass2)==2))/length(seclass2)*100;
        sen3=length(find(globelpredict_label(seclass3)==3))/length(seclass3)*100;
        SEN(:,j)=[sen1;sen2;sen3];
        clear seclass1;clear seclass2;clear seclass3;
    
    elseif K_class==5
        seclass1=find(test_wine_labels==1);
        seclass2=find(test_wine_labels==2);
        seclass3=find(test_wine_labels==3);
        seclass4=find(test_wine_labels==4);
        seclass5=find(test_wine_labels==5);
        sen1=length(find(globelpredict_label(seclass1)==1))/length(seclass1)*100;
        sen2=length(find(globelpredict_label(seclass2)==2))/length(seclass2)*100;
        sen3=length(find(globelpredict_label(seclass3)==3))/length(seclass3)*100;
        sen4=length(find(globelpredict_label(seclass4)==4))/length(seclass4)*100;
        sen5=length(find(globelpredict_label(seclass5)==5))/length(seclass5)*100;
        SEN(:,j)=[sen1;sen2;sen3;sen4;sen5];
        clear seclass1;clear seclass2;clear seclass3;clear seclass4;clear seclass5;
        
    end
        
%%count accuracy

     FINAL_VOT=globelpredict_label;
    rightnum = sum(FINAL_VOT == test_wine_labels);
    accuracy(1,j)=rightnum/length(test_wine_labels)*100;
end

end